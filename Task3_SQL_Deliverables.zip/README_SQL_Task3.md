# SQL Task Deliverables

Files included:

- 01_top_10_orders_by_sales.csv
- 01_top_10_orders_by_sales.png
- 02_monthly_sales.csv
- 02_monthly_sales.png
- 03_avg_profit_by_category.csv
- 03_avg_profit_by_category.png
- 04_orders_in_region_with_join.csv
- 04_orders_in_region_with_join.png
- 05_top_customers_by_revenue.csv
- 05_top_customers_by_revenue.png
- 06_average_revenue_per_user.csv
- 06_average_revenue_per_user.png
- 07_subquery_high_profit_orders.csv
- 07_subquery_high_profit_orders.png
- 09_query_view.csv
- 09_query_view.png
- 11_using_having.csv
- 11_using_having.png
- README_SQL_Task3.md
- queries_task3.sql
- superstore.db
