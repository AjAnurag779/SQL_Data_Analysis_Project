-- 01_top_10_orders_by_sales

SELECT Order_ID, Order_Date, Customer_Name, Segment, Category, Sub_Category, Sales
FROM orders
WHERE Sales IS NOT NULL
ORDER BY Sales DESC
LIMIT 10;


-- 02_monthly_sales

SELECT strftime('%Y-%m', Order_Date) AS Month, ROUND(SUM(Sales),2) AS Total_Sales
FROM orders
GROUP BY Month
ORDER BY Month;


-- 03_avg_profit_by_category

SELECT Category, ROUND(AVG(Profit),2) AS Avg_Profit
FROM orders
GROUP BY Category
ORDER BY Avg_Profit DESC;


-- 04_orders_in_region_with_join

SELECT o.Order_ID, o.Order_Date, o.Sales, o.Profit, c.region
FROM orders o
LEFT JOIN customers c ON o.Customer_ID = c.customer_id
WHERE c.region = 'West'
ORDER BY o.Order_Date DESC
LIMIT 20;


-- 05_top_customers_by_revenue

SELECT Customer_Name, COUNT(*) AS Orders_Count, ROUND(SUM(Sales),2) AS Total_Sales, ROUND(SUM(Profit),2) AS Total_Profit
FROM orders
GROUP BY Customer_Name
ORDER BY Total_Sales DESC
LIMIT 10;


-- 06_average_revenue_per_user

SELECT ROUND(SUM(Sales)/COUNT(DISTINCT Customer_Name),2) AS Avg_Revenue_Per_User FROM orders;


-- 07_subquery_high_profit_orders

SELECT Order_ID, Sales, Profit FROM orders
WHERE Profit > (SELECT AVG(Profit) FROM orders)
ORDER BY Profit DESC
LIMIT 10;


-- 08_create_view_monthly_sales

CREATE VIEW IF NOT EXISTS vw_monthly_sales AS
SELECT strftime('%Y-%m', Order_Date) AS Month, SUM(Sales) AS Total_Sales, SUM(Profit) AS Total_Profit
FROM orders
GROUP BY Month;


-- 09_query_view

SELECT * FROM vw_monthly_sales ORDER BY Month;


-- 10_handle_nulls_example

SELECT SUM(CASE WHEN Teacher_Quality IS NULL OR Teacher_Quality = '' THEN 1 ELSE 0 END) AS Null_TeacherQuality FROM orders;


-- 11_using_having

SELECT Customer_Name, COUNT(*) AS OrdersCount, SUM(Sales) AS Revenue
FROM orders
GROUP BY Customer_Name
HAVING Revenue > 5000
ORDER BY Revenue DESC
LIMIT 10;


-- 12_index_create_example

CREATE INDEX IF NOT EXISTS idx_orders_orderdate ON orders(Order_Date);


